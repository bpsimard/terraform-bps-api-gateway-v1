import requests
import json


def make_query(query, variables, url, headers):
    """
    Make query response
    """
    request = requests.post(url, json={'query': query, 'variables': variables}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))




def lambda_handler(event, context):
    ## READ QUEUE MESSAGE
    # for record in event['Records']:
    #     print("test")
    #     payload = record["body"]
    #     print(str(payload))
#
#
#
#
    create_accont_request = { "awsRoot": "test1", "AccountName": "", "roleArn": "", "trailArn": ""}


    query = """
                mutation {
                CreateAwsAccount(
                    input: {
                        ParentGroupId: "awsRoot",
                        Name: "accountName",
                        Id: "acoundId",
                        RoleArn: "roleArn",
                        TrailArn: "trailArn"}
                ) {
                    Account {
                    Id
                    Name
                    RoleArn
                    ActiveRegions
                    TrailArn
                    }
                }
                }
            """
    variables = {'input': create_accont_request}

    make_query(query, variables,"https://sev1apigraphreportingdev.tylertech.cloud/graphql",None)



lambda_handler(None, None)